The .kya files attached here are KeYmaera X proofs for the two theorems mentioned in our paper -
       "Formal Verification of Swerving Maneuvers for Car Collision Avoidance"

Theorem (1) deals with the proof of equivalence between the implicit and explicit safety regions.
The KeYmaera X model and proof is contained in the file named "Theorem_1".

Theorem (2) deals with proof of collision avoidance when the obstacle is in the implict safety region.
The KeYmaera X model and proof is contained in the file named "Theorem_2".

Together, proofs of theorem (1) & theorem (2) validates our collision avoidance system with the explicit
safety region as the required neccesary and sufficient conditions.

The official page of KeYmaera X tool is given below. The formal verification tool can be downloaded and 
its usage information can be seen on the official page.
http://www.ls.cs.cmu.edu/KeYmaeraX/
