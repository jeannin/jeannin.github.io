safe_keymaerax_proof_diff_2.kya: Model and completed proof for implicit safe region against dyanmics

safe_keymaera_proof_explicit.kya: Model and in-progress proof of equivalence of implicit and explicit safe regions
