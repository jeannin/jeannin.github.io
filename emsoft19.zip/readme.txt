The .kya files attached here are KeYmaera X proofs for the two theorem mentioned in our paper -
       "Formal Verification of Swerving Maneuvers for Car Collision Avoidance"

Theorem (1) deals with the proof of equivalence between the implicit and explicit safety regions for the swerving only model.
The KeYmaera X model and proof is contained in the file named "Single Sided Safety Region Equivalence".

Theorem (2) deals with proof of implict safety region beigh a differential invariant of our dynamics model for the swerving only model.
The KeYmaera X model and proof is contained in the file named "Differential Invariant".

The file Baking while turning model.kya contains the proof of no collision for the braking while swerving maneuver.

The official page of KeYmaera X tool is given below. The formal verification tool can be downloaded and 
its usage information can be seen on the official page.
http://www.ls.cs.cmu.edu/KeYmaeraX/
