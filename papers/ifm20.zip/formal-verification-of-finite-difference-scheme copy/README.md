To run the .v files, following dependencies are needed:

* Coq 8.9.1 (https://github.com/coq/coq/releases/tag/V8.9.1)
* mathcomp 1.9.0 (https://github.com/math-comp/math-comp/releases/tag/mathcomp-1.9.0)
* (opam packages coq- mathcomp-ssreflect, coq-mathcomp-fingroup, coq-mathcomp-algebra)
* Flocq 3.2.0 (http://flocq.gforge.inria.fr/)
* Coquelicot 3.0.3 (http://coquelicot.saclay.inria.fr/)
* coq-interval 3.4.1. (http://coq-interval.gforge.inria.fr/)
* BigNums 8.9.0 ( https://github.com/coq/bignums/releases )


Also, to run the "convergence_2.v", you need to install "CoqLM" library which is available through:
https://www.lri.fr/~faissole/these_coq.html
(Florian Faissole is a PhD student working with Slyvie Boldo - INRIA Saclay)
This library will be installed in "user-contrib" folder and can be imported into "convergence_2.v" using "Require Import" command.
Note that appropriate path needs to be specified.
For instance, in our case the library was installed in "user-contrib/Top" folder.
Thus, we imported the library using:
    Require Import Top.linear_map.
where "linear_map" is a compiled .vo file from CoqLM library.
To run "ode_1__4_.v ", standard Reals library and Coquelicot.Coquelicot library need to be imported. Besides, "Interval.coqapprox.taylor_thm" library
also needs to be imported. This library contains the proof of "Taylor-Lagrange theorem" which is used to prove the consistency of a
finite difference scheme.


