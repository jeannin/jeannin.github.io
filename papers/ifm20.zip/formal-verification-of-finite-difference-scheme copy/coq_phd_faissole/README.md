
This archive contains the Coq proofs associated with Florian Faissole's thesis manuscript. 

There are three folders: 
- Average10 : Part I of the manuscript, correctly rounded average of decimal FP numbers ;
- CoqRK : Part II of the manuscript, rounding error analysis of Runge-Kutta methods ; 
- CoqLM : Part III of the manuscript, formalization of functional analysis results.

The following dependencies are needed: 
- Coq 8.9.1.
- mathcomp 1.9.0.
   (opam packages coq-mathcomp-ssreflect, coq-mathcomp-fingroup, coq-mathcomp-algebra).
- Flocq 3.2.0.
- Coquelicot 3.0.3.
- coq-interval 3.4.1. 
 
Ideally, you just have to install the dependencies and run:

$ cd foo (with foo in {Average10,CoqRK,CoqLM}). 
$ make

