# Formalization of a correctly-rounded algorithm to compute the average of two decimal FP numbers.

Authors: Sylvie Boldo, Florian Faissole, Vincent Tourneur

# Build 

The following dependencies are needed: 
- Coq 8.9.1.
- mathcomp 1.9.0.
   (opam packages coq-mathcomp-ssreflect, coq-mathcomp-fingroup, coq-mathcomp-algebra).
- Flocq 3.2.0.
 
Ideally, you just have to install the dependencies and run:

$ make



