# CoqLM : Coq formalization of functional analysis results.

Authors: Sylvie Boldo, François Clément, Florian Faissole, Micaela Mayero, Vincent Martin. 

# Build 

The following dependencies are needed: 
- Coq 8.9.1.
- mathcomp 1.9.0.
   (opam packages coq-mathcomp-ssreflect, coq-mathcomp-fingroup, coq-mathcomp-algebra).
- Coquelicot 3.0.3.
 
Ideally, you just have to install the dependencies and run:

$ make


